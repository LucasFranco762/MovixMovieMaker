"""Ponto de entrada e coordenação do Movie Maker (REQ-018, 20.2).

Responsabilidades: iniciar logging e configurações, preparar serviços
(FFmpeg, MLT), criar controlador e janela, e coordenar o encerramento.
Nenhuma regra de edição, interface ou renderização mora aqui.
"""
from __future__ import annotations

import logging
import sys
import traceback

from core.configuracoes import criar_configuracoes_padrao, diretorio_dados_usuario
from core.constantes import NOME_APLICATIVO, ORGANIZACAO, VERSAO_APLICATIVO
from core.controlador import Controlador
from core.excecoes import DependenciaAusenteError
from core.logging_config import configurar_logging
from multimidia.motor_ffmpeg import MotorFFmpeg
from multimidia.motor_mlt import MotorMLT

_log = logging.getLogger(NOME_APLICATIVO)


def _preparar_servicos() -> tuple[MotorFFmpeg | None, MotorMLT, list[str]]:
    avisos: list[str] = []
    try:
        ffmpeg: MotorFFmpeg | None = MotorFFmpeg()
        _log.info("FFmpeg: %s", ffmpeg.versao())
    except DependenciaAusenteError as exc:
        ffmpeg = None
        avisos.append(str(exc))
        _log.error("FFmpeg indisponível: %s", exc)
    motor = MotorMLT()
    if not motor.disponivel():
        avisos.append(motor.descricao())
    return ffmpeg, motor, avisos


def main() -> int:
    configurar_logging(diretorio_dados_usuario() / "logs")
    _log.info("Iniciando %s %s", NOME_APLICATIVO, VERSAO_APLICATIVO)

    from PyQt6.QtWidgets import QApplication, QMessageBox   # import tardio: falha clara se ausente
    app = QApplication(sys.argv)
    app.setApplicationName(NOME_APLICATIVO)
    app.setOrganizationName(ORGANIZACAO)

    def ao_excecao_nao_tratada(tipo, valor, tb) -> None:
        """Erros inesperados são registrados e mostrados sem encerrar o aplicativo."""
        _log.critical("Exceção não tratada", exc_info=(tipo, valor, tb))
        QMessageBox.critical(None, "Erro inesperado",
                             f"Ocorreu um erro inesperado:\n{valor}\n\nDetalhes foram gravados no log.")
        traceback.print_exception(tipo, valor, tb)

    sys.excepthook = ao_excecao_nao_tratada

    from interface.estilos import QSS
    from interface.janela_principal import JanelaPrincipal

    app.setStyleSheet(QSS)
    config = criar_configuracoes_padrao()
    ffmpeg, motor, avisos = _preparar_servicos()
    controlador = Controlador(config, motor=motor, ffmpeg=ffmpeg)
    controlador.novo_projeto()

    janela = JanelaPrincipal(controlador, aviso_inicial=" | ".join(avisos))
    janela.mostrar()
    codigo = app.exec()
    controlador.encerrar()
    return codigo


if __name__ == "__main__":
    sys.exit(main())
